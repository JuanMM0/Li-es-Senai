import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import java.io.PrintWriter;

import java.util.*;
 
@WebServlet("/CadastroAlunoServlet")

public class CadastroAlunoServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//pegar os parâmetros da requisição
		request.setCharacterEncoding("UTF-8");

		String nome=request.getParameter("nome");
		String NRF=request.getParameter("NRF");
		String sexo=request.getParameter("sexo");
		String endereco=request.getParameter("endereco");
		String tell=request.getParameter("tell");
		

		GregorianCalendar calendario=new GregorianCalendar();

		String mensagem=calendario.get(Calendar.AM_PM)==Calendar.AM?"Bom dia":"Boa tarde";

		response.setContentType("text/html");

		PrintWriter out=response.getWriter();

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Dados do Funcionário </title>");
		
		out.println("<style>");
		out.println("body{");
		out.println(" 	font-family: \"Poppins\", sans-serif;");
		out.println("   padding: 25px;");
		out.println("   text-align: center;");
		out.println("   background-image: url('Imagem/CLT.webp');");
		out.println("   background-size: cover;");
		out.println("   background-repeat: no-repeat;");
		out.println("   border: 5px solid DeepSkyBlue;");
		out.println("   background-color: Navy;");
		out.println("}");
		out.println("p{");
		out.println("   color:DeepSkyBlue;");
		out.println("}");
		out.println("</style>");
		out.println("</head");
		out.println("<body>");
		out.println("<p>"+mensagem+","+nome+"</p>");
		out.println("<p>Seu Numero de Registro do Funcionário é:"+NRF+"</p>");
		out.println("<p>Sexo:"+sexo+"</p>");
		out.println("<p>Você reside no endereço:"+endereco+"</p>");
		out.println("<p>Seu telefone é:"+tell+"</p>");
		out.println("<p>CLT</p>");
		out.println("</body>");
		
		out.println("</html>");
		out.close();

	}
 
}