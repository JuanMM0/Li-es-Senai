const moves = document.getElementById("moves-count");
const timeValue = document.getElementById("time");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const gameContainer = document.querySelector(".game-container");
const result = document.getElementById("result");
const controls = document.querySelector(".controls-container");
let cards;
let interval;
let firstCard = false;
let secondCard = false;

/* Array guardando nossas imagens que vão ser puxadas mais tarde*/
const items = [
	{ name: "im1", image: "imagem1.png" },
	{ name: "im2", image: "imagem2.png" },
	{ name: "im3", image: "imagem3.png" },
	{ name: "im4", image: "imagem4.png" },
	{ name: "im5", image: "imagem5.png" },
	{ name: "im6", image: "imagem6.png" },
	{ name: "im1", image: "imagem1.png" },
	{ name: "im2", image: "imagem2.png" },
	{ name: "im3", image: "imagem3.png" },
	{ name: "im4", image: "imagem4.png" },
	{ name: "im5", image: "imagem5.png" },
	{ name: "im6", image: "imagem6.png" },
];

/* Essas linhas declaram e inicializam variáveis
para acompanhar o tempo, movimentos e a contagem de pares correspondentes com sucesso. */
let seconds = 0,
	minutes = 0;
let movesCount = 0,
	winCount = 0;

/* Esta função incrementa os segundos e minutos para o cronômetro do jogo e atualiza 
o tempo exibido. */
const timeGenerator = () => {
	seconds += 1;
	if (seconds >= 60) {
		minutes += 1;
		seconds = 0;
	}

	let secondsValue = seconds < 10 ? `0${seconds}` : seconds;
	let minutesValue = minutes < 10 ? `0${minutes}` : minutes;
	timeValue.innerHTML = `<span>Time:</span>${minutesValue}:${secondsValue}`;
};
/* Esta função incrementa a contagem de movimentos e atualiza os movimentos exibidos. */
const movesCounter = () => {
	movesCount += 1;
	moves.innerHTML = `<span>Moves:</span>${movesCount}`;
};

/* Esta função gera um conjunto aleatório de valores de cartas com base no tamanho especificado.
 Garante que cada carta tenha um par correspondente. */
const generateRandom = (size = 4) => {

	let tempArray = [...items];

	let cardValues = [];

	size = (size * size) / 2;

	for (let i = 0; i < size; i++) {
		const randomIndex = Math.floor(Math.random() * tempArray.length);
		cardValues.push(tempArray[randomIndex]);

		tempArray.splice(randomIndex, 1);
	}
	return cardValues;
};
/* matrixGenerator Function:
Essa função é responsável por gerar a grade do jogo (ou tabuleiro) de memória com os cartões.
cardValues: Um array contendo os valores dos cartões a serem utilizados no jogo e logo em seguida
 a definição do valor de quantas cartas terão por fileira. */
const matrixGenerator = (cardValues, size = 4) => {
	gameContainer.innerHTML = "";
/* Aqui é onde as cartas (cardValues) é usado nessa função para ter um par de cartas, duplicando o valor da nossa variavel
para cada uma que for puxada do Array. */
	cardValues = [...cardValues, ...cardValues];
/* Nesta parte o math faz o papel de embaralhar as cartas pelo nossa tabuleiro*/
	cardValues.sort(() => Math.random() - 0.5);
/* Um loop para poder criar as funções nas cartas dentro do nossa container(gameContainer) */
	for (let i = 0; i < size * size; i++) {

		gameContainer.innerHTML += `
     <div class="card-container" data-card-value="${cardValues[i].name}">
        <div class="card-before">?</div>
        <div class="card-after">
        <img src="${cardValues[i].image}" class="image"/></div>
     </div>
     `;
	}
/* Adicionando mais um valor para o container, para fazer as cartas ficarem de um jeito mais 
bonito de um tamanho bom para jogar*/
	gameContainer.style.gridTemplateColumns = `repeat(${size},auto)`;

/* Esta parte faz com que o click do usuário na carta tenha alguma resposta */
	cards = document.querySelectorAll(".card-container");
	cards.forEach((card) => {
		card.addEventListener("click", () => {

			if (!card.classList.contains("matched")) {

				card.classList.add("flipped");

				if (!firstCard) {

					firstCard = card;

					firstCardValue = card.getAttribute("data-card-value");
				} else {

					movesCounter();

					secondCard = card;
					let secondCardValue = card.getAttribute("data-card-value");
					if (firstCardValue == secondCardValue) {

						firstCard.classList.add("matched");
						secondCard.classList.add("matched");

						firstCard = false;

						winCount += 1;

						if (winCount == Math.floor(cardValues.length / 2)) {
							result.innerHTML = `<h2>You Won</h2>
            <h4>Moves: ${movesCount}</h4>`;
							stopGame();
						}
					} else {

						let [tempFirst, tempSecond] = [firstCard, secondCard];
						firstCard = false;
						secondCard = false;
						let delay = setTimeout(() => {
							tempFirst.classList.remove("flipped");
							tempSecond.classList.remove("flipped");
						}, 900);
					}
				}
			}
		});
	});
};
/* Este ouvinte de eventos inicia o jogo quando o botão de início é clicado. */
startButton.addEventListener("click", () => {
	movesCount = 0;
	seconds = 0;
	minutes = 0;

	controls.classList.add("hide");
	stopButton.classList.remove("hide");
	startButton.classList.add("hide");

	interval = setInterval(timeGenerator, 1000);

	moves.innerHTML = `<span>Moves:</span> ${movesCount}`;
	initializer();
});
/* Este ouvinte de eventos encerra o jogo quando o botão de parada é clicado. */
stopButton.addEventListener(
	"click",
	(stopGame = () => {
		controls.classList.remove("hide");
		stopButton.classList.add("hide");
		startButton.classList.remove("hide");
		clearInterval(interval);
	})
);
/* Esta função inicializa o jogo resetando variáveis, gerando um novo conjunto 
de valores de cartas e criando um novo tabuleiro de jogo. */
const initializer = () => {
	result.innerText = "";
	winCount = 0;
	let cardValues = generateRandom();
	console.log(cardValues);
	matrixGenerator(cardValues);
};