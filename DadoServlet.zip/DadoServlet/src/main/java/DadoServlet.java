import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Random;

@WebServlet("/DadoServlet")
public class DadoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int NUM_SIDES = 6;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int d1 = rollDice();
		int d2 = rollDice();
		
		String mensagem = "";
		 
		if (d1 == d2) {
			mensagem = "Os dados apresentam o mesmo valor";
		} else if (d1 > d2) {
			mensagem = "O número no 1º dado é maior";
		} else {
			mensagem = "O número no 2º dado é maior";
		}
 
		response.setContentType("text/html");
		
		

		try (PrintWriter out = response.getWriter()) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title> Rolagem de dados </title>");
			out.println("<style>");
			out.println("body{");
			out.println(" 	font-family: \"Poppins\", sans-serif;");
			out.println("   padding: 25px;");
			out.println("   text-align: center;");
			out.println("   background-image: url('Imagem/BDSP.webp');");
			out.println("   background-size: cover;");
			out.println("   background-repeat: no-repeat;");
			out.println("}");
			out.println("h1{");
			out.println("   color:DeepSkyBlue;");
			out.println("   border: 5px solid DeepSkyBlue;");
			out.println("   background-color: Navy;");
			out.println("}");
			out.println(".dice-number{");
			out.println("   font-size: 40px;");
			out.println("   margin-top: 10px;");
			out.println("   color:LightBlue;");
			out.println("   text-align: left;");
			out.println("   border: 5px solid DeepSkyBlue;");
			out.println("   background-color: Navy;");
			out.println("}");
			out.println(".dice-label{");
			out.println("   color:LightSkyBlue;");
			out.println("}");
			out.println(".mensagem{");
			out.println("   font-size: 40px;");
			out.println("   margin-top: 10px;");
			out.println("   color:LightBlue;");
			out.println("   text-align: left;");
			out.println("   border: 5px solid DeepSkyBlue;");
			out.println("   background-color: Navy;");
			out.println("}");
			out.println("</style>");
			out.println("</head");
			out.println("<body>");
			out.println("<h1>Rolagem de dados</h1>");
			out.println("<div class=\"dice-number\"><span class=\"dice-label\">Dado 1:</span>"+d1+"</div>");
			out.println("<div class=\"dice-number\"><span class=\"dice-label\">Dado 2:</span>"+d2+"</div>");
			out.println("<div class=\"mensagem\">" + mensagem + "</div>");
			out.println("</body>");
			out.println("</html>");
		}

	}
	private int rollDice() {
		Random aleatorio = new Random();
		return aleatorio.nextInt(NUM_SIDES) +1;
	 }
	}


