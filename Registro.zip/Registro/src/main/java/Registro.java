import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Registro")
public class Registro extends HttpServlet {
	private static final long serialVersionUID = 1L;
    ArrayList<String>atividade=new ArrayList<>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tarefas=request.getParameter("tarefa");
		atividade.add(tarefas);
		request.setCharacterEncoding("UTF-8");
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title> Registro de Tarefas </title>");
		
		out.println("<style>");
		out.println("body{");
		out.println(" 	font-family: \"Poppins\", sans-serif;");
		out.println("   padding: 25px;");
		out.println("   text-align: center;");
		out.println("   border: 5px solid DeepSkyBlue;");
		out.println("   background-color: Navy;");
		out.println("}");
		out.println("p{");
		out.println("   color:DeepSkyBlue;");
		out.println("}");
		out.println("</style>");
		out.println("</head");

		out.println("<body>");
		out.println("<p>Tarefa " + atividade +" adicionada</p>");
		
		
		out.println("</body>");
		
		
		
		
		
		
		
		
	}

}
